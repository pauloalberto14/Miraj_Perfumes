/* =========================================================
   MIRAJ PERFUMES — configuração
   ========================================================= */
const WHATSAPP = "5511999999999"; // troque pelo seu número (código do país + DDD + número)

/* Para cadastrar um perfume, basta copiar um bloco abaixo.
   As imagens ficam na pasta /images (ex.: images/asad.jpg). */
/* A lista de perfumes (PRODUTOS) fica em produtos.js */

const FAMILIAS = ["Todos", "Oriental / Ambarado", "Gourmand", "Fresco / Cítrico", "Floral"];

/* =========================================================
   Utilidades
   ========================================================= */
const $ = (sel) => document.querySelector(sel);
const brl = (v) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const precoTxt = (v) => (v == null ? "Consulte" : brl(v));
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const img = (src, alt = "") => `<img src="${esc(src)}" alt="${esc(alt)}" loading="lazy" onerror="this.style.display='none'">`;

let filtroAtual = "Todos";
let termoBusca = "";
let sacola = JSON.parse(localStorage.getItem("miraj-sacola") || "[]"); // [{id, qtd}]

/* =========================================================
   Hero: carrossel de destaques (rolagem automática)
   ========================================================= */
const destaques = PRODUTOS.filter((p) => p.destaque);

function renderDestaques() {
  const track = $("#destaquesTrack");
  const largura = 256 + 12; // largura de cada mini-card + espaço
  // repete os itens o bastante para cobrir a tela inteira, sem buracos
  const reps = Math.max(1, Math.ceil(window.innerWidth / (destaques.length * largura)) + 1);

  const cards = Array.from({ length: reps }, () => destaques)
    .flat()
    .map(
      (p) => `
      <button type="button" class="mini" data-id="${p.id}">
        <div class="mini__img">${img(p.imagem, p.nome)}</div>
        <div>
          <small>${esc(p.marca)}</small>
          <strong>${esc(p.nome)}</strong>
          <span>${precoTxt(p.preco)}</span>
        </div>
      </button>`
    )
    .join("");

  // dois conjuntos idênticos: a animação percorre um e recomeça sem salto
  track.innerHTML = `<div class="destaques__set">${cards}</div><div class="destaques__set" aria-hidden="true">${cards}</div>`;

  track.querySelectorAll(".mini").forEach((el) =>
    el.addEventListener("click", () => abrirProduto(Number(el.dataset.id)))
  );
}

/* Destaque do início: fotos de campanha que passam sozinhas */
const HERO_INTERVALO_MS = 5500;

const slugDe = (p) => p.imagem.split("/").pop().replace(/\.jpg$/, "");
const produtoPorSlug = (s) => PRODUTOS.find((p) => slugDe(p) === s);
const modelosDe = (p) => (typeof MODELOS === "undefined" ? [] : MODELOS.filter((m) => m.slug === slugDe(p)));

function renderHero() {
  const figura = $("#heroFeature");
  if (!figura) return;
  const lista = typeof MODELOS !== "undefined" && MODELOS.length
    ? MODELOS
    : destaques.map((p) => ({ arquivo: p.imagem, alt: p.nome, slug: slugDe(p) }));
  if (!lista.length) return;
  let atual = 0, timer = null;

  $("#heroSlides").innerHTML = lista
    .map((m, i) => `<div class="slide${i === 0 ? " is-active" : ""}"><img class="slide__bg" alt="" aria-hidden="true"><img class="slide__img" alt="${esc(m.alt || "")}"></div>`)
    .join("");
  const slides = [...document.querySelectorAll("#heroSlides .slide")];

  // carrega só a foto atual e a próxima, para o site abrir rápido
  function carregar(i) {
    const k = (i + lista.length) % lista.length, s = slides[k];
    if (s.dataset.ok) return;
    s.dataset.ok = "1";
    s.querySelectorAll("img").forEach((im) => { im.onerror = () => { im.style.visibility = "hidden"; }; im.src = lista[k].arquivo; });
  }

  function mostrar(i) {
    atual = (i + lista.length) % lista.length;
    carregar(atual); carregar(atual + 1);
    slides.forEach((s, k) => s.classList.toggle("is-active", k === atual));
    $("#heroCount").textContent = `${String(atual + 1).padStart(2, "0")} / ${lista.length}`;
    figura.setAttribute("aria-label", `Ver detalhes: ${lista[atual].alt || "perfume em destaque"}`);
  }

  const parar = () => { clearInterval(timer); timer = null; };
  const iniciar = () => { parar(); if (lista.length > 1) timer = setInterval(() => mostrar(atual + 1), HERO_INTERVALO_MS); };

  mostrar(0);
  iniciar();

  figura.addEventListener("mouseenter", parar);
  figura.addEventListener("mouseleave", iniciar);
  figura.addEventListener("focusin", parar);
  figura.addEventListener("focusout", iniciar);
  document.addEventListener("visibilitychange", () => (document.hidden ? parar() : iniciar()));

  $("#heroPrev").addEventListener("click", (e) => { e.stopPropagation(); mostrar(atual - 1); });
  $("#heroNext").addEventListener("click", (e) => { e.stopPropagation(); mostrar(atual + 1); });

  const abrir = () => {
    const p = lista[atual].slug && produtoPorSlug(lista[atual].slug);
    if (p) abrirProduto(p.id);
    else document.getElementById("catalogo").scrollIntoView({ behavior: "smooth" });
  };
  figura.addEventListener("click", abrir);
  figura.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); abrir(); }
    if (e.key === "ArrowRight") mostrar(atual + 1);
    if (e.key === "ArrowLeft") mostrar(atual - 1);
  });
}

function irParaProduto(id) {
  filtroAtual = "Todos";
  termoBusca = "";
  $("#busca").value = "";
  renderFiltros();
  renderGrid();
  const card = document.querySelector(`.card[data-id="${id}"]`);
  if (card) card.scrollIntoView({ behavior: "smooth", block: "center" });
}

/* =========================================================
   Catálogo: filtros, busca e cards
   ========================================================= */
function renderFiltros() {
  $("#filtros").innerHTML = FAMILIAS.map(
    (f) => `<button type="button" class="chip ${f === filtroAtual ? "is-active" : ""}" data-f="${esc(f)}">${esc(f)}</button>`
  ).join("");

  document.querySelectorAll(".chip").forEach((el) =>
    el.addEventListener("click", () => {
      filtroAtual = el.dataset.f;
      renderFiltros();
      renderGrid();
    })
  );
}

function renderGrid() {
  const t = termoBusca.trim().toLowerCase();
  const lista = PRODUTOS.filter((p) => {
    const okFamilia = filtroAtual === "Todos" || p.familia === filtroAtual;
    const texto = [p.nome, p.marca, p.familia, ...p.notas].join(" ").toLowerCase();
    return okFamilia && (!t || texto.includes(t));
  });

  $("#grid").innerHTML = lista
    .map(
      (p) => `
      <article class="card" data-id="${p.id}" tabindex="0" role="button" aria-label="Ver detalhes de ${esc(p.nome)}">
        <div class="card__img">
          ${p.destaque ? '<span class="badge">DESTAQUE</span>' : ""}
          ${img(p.imagem, p.nome)}
        </div>
        <div class="card__body">
          <p class="card__brand">${esc(p.marca)}</p>
          <h3 class="card__name">${esc(p.nome)}</h3>
          <p class="card__meta">${esc(p.volume)} · ${esc(p.tipo)}</p>
          <p class="card__notes"><span>Cheira a</span> ${p.notas.map(esc).join(" · ")}</p>
          <div class="card__foot">
            <span class="card__price">${precoTxt(p.preco)}</span>
            <button type="button" class="add" data-add="${p.id}" aria-label="Adicionar ${esc(p.nome)} à sacola">+</button>
          </div>
        </div>
      </article>`
    )
    .join("");

  $("#vazio").hidden = lista.length > 0;

  document.querySelectorAll(".card").forEach((card) => {
    const abrir = () => abrirProduto(Number(card.dataset.id));
    card.addEventListener("click", (e) => { if (!e.target.closest("[data-add]")) abrir(); });
    card.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && e.target === card) { e.preventDefault(); abrir(); } });
  });

  document.querySelectorAll("[data-add]").forEach((btn) =>
    btn.addEventListener("click", () => {
      adicionar(Number(btn.dataset.add));
      abrirSacola();
    })
  );
}

$("#busca").addEventListener("input", (e) => {
  termoBusca = e.target.value;
  renderGrid();
});

/* =========================================================
   Sacola
   ========================================================= */
function salvar() {
  localStorage.setItem("miraj-sacola", JSON.stringify(sacola));
}

function adicionar(id) {
  const item = sacola.find((i) => i.id === id);
  item ? item.qtd++ : sacola.push({ id, qtd: 1 });
  renderSacola();
}

function alterarQtd(id, delta) {
  const item = sacola.find((i) => i.id === id);
  if (!item) return;
  item.qtd += delta;
  if (item.qtd <= 0) sacola = sacola.filter((i) => i.id !== id);
  renderSacola();
}

function remover(id) {
  sacola = sacola.filter((i) => i.id !== id);
  renderSacola();
}

function renderSacola() {
  salvar();
  const itens = sacola
    .map((i) => ({ ...PRODUTOS.find((p) => p.id === i.id), qtd: i.qtd }))
    .filter((i) => i.id);

  const total = itens.reduce((s, i) => s + (i.preco || 0) * i.qtd, 0);
  const qtdTotal = itens.reduce((s, i) => s + i.qtd, 0);

  const contador = $("#contador");
  contador.textContent = qtdTotal;
  contador.hidden = qtdTotal === 0;

  $("#totalSacola").textContent = brl(total);
  $("#finalizar").disabled = itens.length === 0;

  $("#itensSacola").innerHTML = itens.length
    ? itens
        .map(
          (i) => `
        <div class="item">
          <div class="item__img">${img(i.imagem, i.nome)}</div>
          <div class="item__info">
            <small>${esc(i.marca)}</small>
            <strong>${esc(i.nome)}</strong>
            <span class="price">${i.preco == null ? "Sob consulta" : brl(i.preco * i.qtd)}</span>
            <div class="qty">
              <button type="button" data-menos="${i.id}" aria-label="Diminuir">−</button>
              <span>${i.qtd}</span>
              <button type="button" data-mais="${i.id}" aria-label="Aumentar">+</button>
            </div>
          </div>
          <button type="button" class="item__remove" data-rem="${i.id}">Remover</button>
        </div>`
        )
        .join("")
    : '<p class="drawer__empty">Sua sacola está vazia. Escolha um perfume no catálogo.</p>';

  document.querySelectorAll("[data-menos]").forEach((b) => b.addEventListener("click", () => alterarQtd(Number(b.dataset.menos), -1)));
  document.querySelectorAll("[data-mais]").forEach((b) => b.addEventListener("click", () => alterarQtd(Number(b.dataset.mais), 1)));
  document.querySelectorAll("[data-rem]").forEach((b) => b.addEventListener("click", () => remover(Number(b.dataset.rem))));
}

function abrirSacola() {
  $("#drawer").classList.add("is-open");
  $("#drawer").setAttribute("aria-hidden", "false");
  $("#overlay").hidden = false;
}
function fecharSacola() {
  $("#drawer").classList.remove("is-open");
  $("#drawer").setAttribute("aria-hidden", "true");
  $("#overlay").hidden = true;
}

$("#abrirSacola").addEventListener("click", abrirSacola);
$("#fecharSacola").addEventListener("click", fecharSacola);
$("#overlay").addEventListener("click", fecharSacola);
document.addEventListener("keydown", (e) => e.key === "Escape" && fecharSacola());

$("#finalizar").addEventListener("click", () => {
  const linhas = sacola.map((i) => {
    const p = PRODUTOS.find((x) => x.id === i.id);
    return `• ${i.qtd}x ${p.nome} (${p.marca}) — ${p.preco == null ? "sob consulta" : brl(p.preco * i.qtd)}`;
  });
  const total = sacola.reduce((s, i) => s + (PRODUTOS.find((x) => x.id === i.id).preco || 0) * i.qtd, 0);
  const temConsulta = sacola.some((i) => PRODUTOS.find((x) => x.id === i.id).preco == null);
  const msg = `Olá! Gostaria de fazer este pedido:\n\n${linhas.join("\n")}\n\nTotal: ${brl(total)}${temConsulta ? " (+ itens sob consulta)" : ""}`;
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, "_blank", "noopener");
});

/* =========================================================
   Modal de detalhes do perfume
   ========================================================= */
const ICONES = {
  conteudo: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 18l-5-9V3"/><path d="M7.5 15h9"/></svg>',
  concentracao: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11Z"/></svg>',
  origem: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
  familia: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12V4h8l10 10-8 8L3 12Z"/><circle cx="7.5" cy="8.5" r="1.2"/></svg>',
  sacola: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8h14l-1 12H6L5 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>',
  whats: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11.5a8.5 8.5 0 0 1-12.6 7.4L3 20l1.2-4.2A8.5 8.5 0 1 1 20 11.5Z"/><path d="M9 8.5c0 3 3 6 6 6l1.2-1.3-2-1-1 .6a4 4 0 0 1-2-2l.6-1-1-2L9 8.5Z"/></svg>',
};

let produtoAberto = null;
let focoAnterior = null;

function montarGaleria(p) {
  const caixa = $("#mImg");
  const fotos = [
    { src: p.imagem, alt: p.nome, contain: false },
    ...modelosDe(p).map((m) => ({ src: m.arquivo, alt: m.alt || p.nome, contain: true })),
  ];
  caixa.innerHTML =
    '<div class="m-stage"><img class="m-bg" alt="" aria-hidden="true"><img class="m-fg" alt=""></div>' +
    (fotos.length > 1
      ? `<div class="m-thumbs">${fotos
          .map((f, i) => `<button type="button" class="m-thumb${i === 0 ? " is-active" : ""}" data-i="${i}" aria-label="Foto ${i + 1} de ${fotos.length}"><img src="${esc(f.src)}" alt=""></button>`)
          .join("")}</div>`
      : "");
  const bg = caixa.querySelector(".m-bg"), fg = caixa.querySelector(".m-fg");
  [bg, fg].forEach((im) => { im.onerror = () => { im.style.visibility = "hidden"; }; });
  const ir = (i) => {
    const f = fotos[i];
    bg.style.visibility = fg.style.visibility = "visible";
    fg.src = f.src; fg.alt = f.alt; bg.src = f.src;
    caixa.classList.toggle("is-contain", f.contain);
    caixa.querySelectorAll(".m-thumb").forEach((b, k) => b.classList.toggle("is-active", k === i));
  };
  caixa.querySelectorAll(".m-thumb").forEach((b) => b.addEventListener("click", () => ir(Number(b.dataset.i))));
  ir(0);
}

function abrirProduto(id) {
  const p = PRODUTOS.find((x) => x.id === id);
  if (!p) return;
  produtoAberto = p;
  focoAnterior = document.activeElement;

  const semPreco = p.preco == null;

  montarGaleria(p);
  $("#mMarca").textContent = p.marca;
  $("#mNome").textContent = p.nome;
  $("#mDesc").textContent = p.descricao || "";
  $("#mInfo").innerHTML = [
    ["conteudo", "Conteúdo", p.volume],
    ["concentracao", "Concentração", p.tipo],
    ["origem", "Origem", p.origem || "Emirados Árabes"],
    ["familia", "Família", p.familia],
  ]
    .map(([ic, rotulo, valor]) => `<div>${ICONES[ic]}<dt>${rotulo}</dt><dd>${esc(valor)}</dd></div>`)
    .join("");
  $("#mNotas").innerHTML = p.notas.map((n) => `<span class="chip-note">${esc(n)}</span>`).join("");
  $("#mTags").innerHTML = (p.tags || []).map((t) => `<span class="tag">${esc(t)}</span>`).join("");
  $("#mTags").hidden = !(p.tags && p.tags.length);

  $("#mPreco").textContent = semPreco ? "Sob consulta" : brl(p.preco);
  $("#mHint").hidden = !semPreco;

  const add = $("#mAdd");
  add.disabled = semPreco;
  add.title = semPreco ? "Este perfume é vendido sob consulta" : "";
  add.innerHTML = `${ICONES.sacola} Adicionar à sacola`;

  const msg = semPreco
    ? `Olá! Gostaria de saber o preço do ${p.nome} (${p.marca}) ${p.volume}.`
    : `Olá! Gostaria de pedir o ${p.nome} (${p.marca}) ${p.volume} — ${brl(p.preco)}.`;
  const wa = $("#mWhats");
  wa.href = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`;
  wa.innerHTML = `${ICONES.whats} ${semPreco ? "Consultar no WhatsApp" : "Pedir no WhatsApp"}`;

  $("#modal").hidden = false;
  document.body.style.overflow = "hidden";
  $("#modal .modal__close").focus();
}

function fecharProduto() {
  if ($("#modal").hidden) return;
  $("#modal").hidden = true;
  document.body.style.overflow = "";
  produtoAberto = null;
  if (focoAnterior && focoAnterior.focus) focoAnterior.focus();
}

document.querySelectorAll("#modal [data-close]").forEach((el) => el.addEventListener("click", fecharProduto));
document.addEventListener("keydown", (e) => e.key === "Escape" && fecharProduto());
$("#mAdd").addEventListener("click", () => {
  if (!produtoAberto || produtoAberto.preco == null) return;
  adicionar(produtoAberto.id);
  fecharProduto();
  abrirSacola();
});

/* =========================================================
   Inicialização
   ========================================================= */
$("#linkWhats").href = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Olá! Vim pelo site da Miraj Perfumes.")}`;

renderDestaques();
renderHero();
renderFiltros();
renderGrid();
renderSacola();
