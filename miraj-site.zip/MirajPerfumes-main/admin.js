/* =========================================================
   MIRAJ — painel interno de estoque
   Perfis:  dono         → vê e altera tudo
            funcionario  → só visualiza (sem custo e sem botões de edição)

   ATENÇÃO: este painel roda só no navegador. Os dados ficam salvos no
   aparelho de quem usa e a proteção é apenas na tela. Para vários
   aparelhos compartilharem o mesmo estoque, e para segurança de
   verdade, é preciso um servidor (banco de dados + login).
   ========================================================= */
(() => {
  "use strict";

  /* ---------- utilidades ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const brl = (v) => (v == null || v === "" ? "—" : Number(v).toLocaleString("pt-BR", { style: "currency", currency: "BRL" }));
  const dataHora = (t) => new Date(t).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  const PAPEIS = { dono: "Dono", funcionario: "Funcionário" };

  /* ---------- armazenamento (com reserva em memória) ---------- */
  const CHAVE = "miraj-admin-v1";
  const CHAVE_SESSAO = "miraj-admin-sessao";
  const INATIVIDADE_MS = 30 * 60 * 1000;

  const lerLS = (k, store = localStorage) => { try { return store.getItem(k); } catch (e) { return null; } };
  const gravarLS = (k, v, store = localStorage) => { try { store.setItem(k, v); } catch (e) { /* segue só em memória */ } };
  const apagarLS = (k, store = localStorage) => { try { store.removeItem(k); } catch (e) { /* ignora */ } };

  let db = { versao: 1, usuarios: [], estoque: {}, movs: [] };
  try { const salvo = JSON.parse(lerLS(CHAVE) || "null"); if (salvo && Array.isArray(salvo.usuarios)) db = salvo; } catch (e) { /* começa vazio */ }
  const salvar = () => gravarLS(CHAVE, JSON.stringify(db));

  /* ---------- senhas (PBKDF2 + sal aleatório) ---------- */
  const enc = new TextEncoder();
  const paraB64 = (b) => btoa(String.fromCharCode(...b));
  const deB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

  async function hashSenha(senha, salB64) {
    if (!(window.crypto && crypto.subtle)) throw new Error("Este navegador não suporta criptografia. Abra o painel por https ou em um navegador atual.");
    const chave = await crypto.subtle.importKey("raw", enc.encode(senha), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: deB64(salB64), iterations: 150000, hash: "SHA-256" }, chave, 256);
    return paraB64(new Uint8Array(bits));
  }
  const novoSal = () => paraB64(crypto.getRandomValues(new Uint8Array(16)));

  async function novoUsuario({ nome, usuario, senha, papel }) {
    usuario = usuario.trim().toLowerCase();
    if (!nome.trim() || !usuario) throw new Error("Preencha nome e usuário.");
    if (!/^[a-z0-9._-]{3,30}$/.test(usuario)) throw new Error("Usuário: 3 a 30 letras minúsculas, números, ponto, hífen ou _.");
    if (senha.length < 8) throw new Error("A senha precisa ter pelo menos 8 caracteres.");
    if (db.usuarios.some((u) => u.usuario === usuario)) throw new Error("Já existe um usuário com esse nome.");
    const sal = novoSal();
    return { id: uid(), nome: nome.trim(), usuario, papel, sal, hash: await hashSenha(senha, sal), criado: Date.now() };
  }

  /* ---------- sessão ---------- */
  let sessao = null; // { id, papel, nome }
  let timerInatividade = null;

  const ehDono = () => !!sessao && sessao.papel === "dono";
  function exigeDono() { if (!ehDono()) throw new Error("Sem permissão: apenas o dono pode alterar."); }

  function iniciarSessao(u) {
    sessao = { id: u.id, papel: u.papel, nome: u.nome };
    gravarLS(CHAVE_SESSAO, JSON.stringify({ id: u.id, t: Date.now() }), sessionStorage);
    reiniciarInatividade();
  }
  function encerrarSessao(msg) {
    sessao = null;
    apagarLS(CHAVE_SESSAO, sessionStorage);
    clearTimeout(timerInatividade);
    if ($("#dlg").open) $("#dlg").close();
    mostrarTelaLogin();
    if (msg) $("#loginErro").textContent = msg;
  }
  function reiniciarInatividade() {
    clearTimeout(timerInatividade);
    if (sessao) timerInatividade = setTimeout(() => encerrarSessao("Sessão encerrada por inatividade."), INATIVIDADE_MS);
  }
  ["click", "keydown", "touchstart"].forEach((ev) => document.addEventListener(ev, reiniciarInatividade, { passive: true }));

  /* ---------- estoque ---------- */
  const PADRAO = { qtd: 0, min: 2, custo: null, preco: null };
  const est = (p) => {
    const e = db.estoque[p.id];
    return e ? { ...PADRAO, ...e } : { ...PADRAO, preco: p.preco ?? null };
  };
  function gravarEst(p, parcial) {
    db.estoque[p.id] = { ...est(p), ...parcial };
  }
  const situacao = (e) => (e.qtd <= 0 ? "esgotado" : e.qtd <= e.min ? "baixo" : "ok");
  const ROTULO = { ok: "Em estoque", baixo: "Estoque baixo", esgotado: "Esgotado" };

  function registrar(p, tipo, delta, saldo, motivo) {
    db.movs.unshift({ t: Date.now(), uid: sessao.id, quem: sessao.nome, pid: p.id, tipo, delta, saldo, motivo });
    db.movs = db.movs.slice(0, 500);
  }

  /** Aplica uma movimentação. tipo: entrada | saida | contagem */
  function movimentar(p, tipo, valor, motivo) {
    exigeDono();
    const atual = est(p).qtd;
    let novo;
    if (tipo === "entrada") novo = atual + valor;
    else if (tipo === "saida") { if (valor > atual) throw new Error(`Saída maior que o estoque (${atual}).`); novo = atual - valor; }
    else novo = valor;
    if (!Number.isInteger(novo) || novo < 0) throw new Error("Quantidade inválida.");
    if (novo === atual) return;
    gravarEst(p, { qtd: novo });
    registrar(p, tipo === "contagem" ? "ajuste" : tipo, novo - atual, novo, motivo);
    salvar();
  }

  function editarDados(p, { preco, custo, min }) {
    exigeDono();
    const e = est(p);
    const mudancas = [];
    if (preco !== e.preco) mudancas.push(`preço ${brl(e.preco)} → ${brl(preco)}`);
    if (custo !== e.custo) mudancas.push(`custo ${brl(e.custo)} → ${brl(custo)}`);
    if (min !== e.min) mudancas.push(`mínimo ${e.min} → ${min}`);
    if (!mudancas.length) return;
    gravarEst(p, { preco, custo, min });
    registrar(p, "edicao", 0, e.qtd, mudancas.join("; "));
    salvar();
  }

  /* ---------- interface: telas ---------- */
  function mostrarTelaLogin() {
    $("#app").hidden = true;
    $("#login").hidden = false;
    const primeiro = db.usuarios.length === 0;
    $("#formSetup").hidden = !primeiro;
    $("#formLogin").hidden = primeiro;
    $("#loginSenha").value = "";
    (primeiro ? $("#setupNome") : $("#loginUsuario")).focus();
  }

  function mostrarApp() {
    $("#login").hidden = true;
    $("#app").hidden = false;
    $("#userNome").textContent = sessao.nome;
    const chip = $("#userPapel");
    chip.textContent = PAPEIS[sessao.papel];
    chip.classList.toggle("role--leitura", !ehDono());
    $("#bannerLeitura").hidden = ehDono();
    $$("[data-dono]").forEach((el) => (el.hidden = !ehDono()));
    abrirAba("estoque");
    renderTudo();
  }

  function abrirAba(nome) {
    if ((nome === "usuarios" || nome === "backup") && !ehDono()) nome = "estoque";
    $$("#tabs button").forEach((b) => b.classList.toggle("is-active", b.dataset.tab === nome));
    ["estoque", "movs", "usuarios", "backup"].forEach((t) => ($("#tab-" + t).hidden = t !== nome));
    if (nome === "movs") renderMovs();
    if (nome === "usuarios") renderUsuarios();
  }

  function toast(msg, erro = false) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.toggle("toast--erro", erro);
    t.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (t.hidden = true), 3200);
  }

  /* ---------- interface: estoque ---------- */
  const filtro = { q: "", familia: "", status: "", ordem: "nome" };
  const norm = (s) => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

  function listaFiltrada() {
    const q = norm(filtro.q.trim());
    let lista = PRODUTOS.filter((p) => {
      const e = est(p);
      if (filtro.familia && p.familia !== filtro.familia) return false;
      if (filtro.status && situacao(e) !== filtro.status) return false;
      return !q || norm(`${p.nome} ${p.marca}`).includes(q);
    });
    const cmpNome = (a, b) => a.nome.localeCompare(b.nome, "pt-BR");
    if (filtro.ordem === "menor") lista.sort((a, b) => est(a).qtd - est(b).qtd || cmpNome(a, b));
    else if (filtro.ordem === "maior") lista.sort((a, b) => est(b).qtd - est(a).qtd || cmpNome(a, b));
    else lista.sort(cmpNome);
    return lista;
  }

  function renderResumo() {
    let unidades = 0, valorVenda = 0, valorCusto = 0, alertas = 0, esgotados = 0;
    PRODUTOS.forEach((p) => {
      const e = est(p);
      unidades += e.qtd;
      valorVenda += e.qtd * (e.preco || 0);
      valorCusto += e.qtd * (e.custo || 0);
      const s = situacao(e);
      if (s === "baixo") alertas++;
      if (s === "esgotado") esgotados++;
    });
    const cards = [
      ["Perfumes cadastrados", PRODUTOS.length],
      ["Unidades em estoque", unidades.toLocaleString("pt-BR")],
      ["Valor em estoque (venda)", brl(valorVenda)],
    ];
    if (ehDono()) cards.push(["Valor em estoque (custo)", brl(valorCusto)]);
    cards.push(["Estoque baixo", alertas, "alert"], ["Esgotados", esgotados, "alert"]);
    $("#resumo").innerHTML = cards
      .map(([r, v, k]) => `<div class="stat ${k ? "stat--alert" : ""}"><small>${r}</small><strong>${v}</strong></div>`)
      .join("");
  }

  function renderTabela() {
    const dono = ehDono();
    $("#thead").innerHTML = `<tr>
      <th>Perfume</th><th>Família</th><th class="num">Quantidade</th><th class="num">Mínimo</th>
      <th class="num">Preço de venda</th>${dono ? '<th class="num">Custo</th>' : ""}<th>Situação</th>${dono ? "<th></th>" : ""}</tr>`;

    const lista = listaFiltrada();
    $("#tbody").innerHTML = lista.map((p) => {
      const e = est(p), s = situacao(e);
      const qtd = dono
        ? `<div class="qty"><button type="button" data-dec="${p.id}" aria-label="Diminuir 1">−</button>
             <input type="number" min="0" step="1" value="${e.qtd}" data-qtd="${p.id}" aria-label="Quantidade de ${esc(p.nome)}">
             <button type="button" data-inc="${p.id}" aria-label="Aumentar 1">+</button></div>`
        : `<span class="qty-ro">${e.qtd}</span>`;
      return `<tr>
        <td><div class="prod"><span class="prod__img"><img src="${esc(p.imagem)}" alt="" loading="lazy" onerror="this.style.display='none'"></span>
          <span><strong>${esc(p.nome)}</strong><small>${esc(p.marca)} · ${esc(p.volume)}</small></span></div></td>
        <td>${esc(p.familia)}</td>
        <td class="num">${qtd}</td>
        <td class="num">${e.min}</td>
        <td class="num">${brl(e.preco)}</td>
        ${dono ? `<td class="num">${brl(e.custo)}</td>` : ""}
        <td><span class="badge badge--${s}">${ROTULO[s]}</span></td>
        ${dono ? `<td class="num"><button class="btn btn--ghost btn--sm" type="button" data-ajustar="${p.id}">Ajustar</button></td>` : ""}
      </tr>`;
    }).join("") || `<tr><td colspan="8" class="muted" style="padding:28px;text-align:center">Nenhum perfume encontrado.</td></tr>`;

    $("#contagem").textContent = `${lista.length} de ${PRODUTOS.length} perfumes`;
  }

  function renderTudo() { renderResumo(); renderTabela(); }

  const produto = (id) => PRODUTOS.find((p) => String(p.id) === String(id));

  function ajusteRapido(p, novoValor, motivo) {
    try {
      movimentar(p, "contagem", novoValor, motivo);
      renderTudo();
    } catch (err) { toast(err.message, true); renderTudo(); }
  }

  /* ---------- interface: movimentações ---------- */
  function renderMovs() {
    const tipoTxt = { entrada: "Entrada", saida: "Saída", ajuste: "Ajuste", edicao: "Edição" };
    $("#movsBody").innerHTML = db.movs.map((m) => {
      const p = produto(m.pid);
      const d = m.tipo === "edicao" ? "—" : (m.delta > 0 ? "+" : "") + m.delta;
      const cls = m.delta > 0 ? "pos" : m.delta < 0 ? "neg" : "";
      return `<tr><td>${dataHora(m.t)}</td><td>${esc(m.quem)}</td><td>${esc(p ? p.nome : "#" + m.pid)}</td>
        <td>${tipoTxt[m.tipo] || esc(m.tipo)}</td><td class="num ${cls}">${d}</td>
        <td class="num">${m.saldo}</td><td>${esc(m.motivo || "")}</td></tr>`;
    }).join("") || `<tr><td colspan="7" class="muted" style="padding:28px;text-align:center">Nenhuma movimentação registrada ainda.</td></tr>`;
  }

  /* ---------- interface: usuários ---------- */
  function renderUsuarios() {
    $("#usersBody").innerHTML = db.usuarios.map((u) => {
      const eu = u.id === sessao.id;
      return `<tr><td>${esc(u.nome)} ${eu ? '<span class="muted small">(você)</span>' : ""}</td><td>${esc(u.usuario)}</td>
        <td><em class="role ${u.papel === "dono" ? "" : "role--leitura"}">${PAPEIS[u.papel]}</em></td>
        <td>${dataHora(u.criado)}</td>
        <td class="num"><div class="row" style="justify-content:flex-end">
          <button class="btn btn--ghost btn--sm" type="button" data-senha="${u.id}">Nova senha</button>
          ${eu ? "" : `<button class="btn btn--danger btn--sm" type="button" data-remover="${u.id}">Remover</button>`}
        </div></td></tr>`;
    }).join("");
  }

  /* ---------- janelas ---------- */
  function abrirDialogo(html) {
    const d = $("#dlg");
    d.innerHTML = html;
    d.showModal();
    return d;
  }
  const fechar = () => $("#dlg").close();

  function dialogoAjuste(p) {
    const e = est(p);
    const d = abrirDialogo(`
      <h3>${esc(p.nome)}</h3>
      <p class="muted">${esc(p.marca)} · ${esc(p.volume)} · estoque atual: <strong>${e.qtd}</strong></p>
      <form id="fAjuste">
        <fieldset><legend>Movimentar estoque</legend>
          <div class="grid2">
            <label>Tipo
              <select id="aTipo">
                <option value="entrada">Entrada (somar)</option>
                <option value="saida">Saída (subtrair)</option>
                <option value="contagem">Contagem (definir total)</option>
              </select></label>
            <label>Quantidade <input id="aQtd" type="number" min="0" step="1" placeholder="0"></label>
          </div>
          <label>Motivo
            <select id="aMotivo">
              <option>Compra de fornecedor</option><option>Venda</option><option>Devolução</option>
              <option>Perda ou avaria</option><option>Contagem de inventário</option><option>Outro</option>
            </select></label>
          <label>Observação (opcional) <input id="aObs" maxlength="120"></label>
        </fieldset>
        <fieldset><legend>Dados do produto</legend>
          <div class="grid3">
            <label>Preço de venda (R$) <input id="aPreco" type="number" min="0" step="0.01" value="${e.preco ?? ""}"></label>
            <label>Custo (R$) <input id="aCusto" type="number" min="0" step="0.01" value="${e.custo ?? ""}"></label>
            <label>Estoque mínimo <input id="aMin" type="number" min="0" step="1" value="${e.min}"></label>
          </div>
        </fieldset>
        <p class="erro" id="aErro" role="alert"></p>
        <div class="dlg__actions">
          <button class="btn btn--ghost" type="button" id="aCancelar">Cancelar</button>
          <button class="btn btn--gold" type="submit">Salvar</button>
        </div>
      </form>`);
    $("#aCancelar", d).addEventListener("click", fechar);
    $("#fAjuste", d).addEventListener("submit", (ev) => {
      ev.preventDefault();
      try {
        const num = (id) => { const v = $(id, d).value.trim(); return v === "" ? null : Number(v); };
        const preco = num("#aPreco"), custo = num("#aCusto"), min = num("#aMin");
        if ([preco, custo].some((v) => v != null && (isNaN(v) || v < 0))) throw new Error("Preço e custo precisam ser números positivos.");
        if (min == null || !Number.isInteger(min) || min < 0) throw new Error("Estoque mínimo inválido.");
        const qtd = num("#aQtd");
        if (qtd != null) {
          if (!Number.isInteger(qtd) || qtd < 0) throw new Error("A quantidade deve ser um número inteiro.");
          const obs = $("#aObs", d).value.trim();
          movimentar(p, $("#aTipo", d).value, qtd, $("#aMotivo", d).value + (obs ? ` — ${obs}` : ""));
        }
        editarDados(p, { preco, custo, min });
        fechar(); renderTudo(); toast("Alterações salvas.");
      } catch (err) { $("#aErro", d).textContent = err.message; }
    });
  }

  function dialogoSenha(u) {
    const d = abrirDialogo(`
      <h3>Nova senha</h3><p class="muted">${esc(u.nome)} (${esc(u.usuario)})</p>
      <form id="fSenha">
        <label>Nova senha <span class="muted">(mínimo 8 caracteres)</span><input id="sNova" type="password" minlength="8" autocomplete="new-password" required></label>
        <p class="erro" id="sErro" role="alert"></p>
        <div class="dlg__actions">
          <button class="btn btn--ghost" type="button" id="sCancelar">Cancelar</button>
          <button class="btn btn--gold" type="submit">Salvar senha</button>
        </div>
      </form>`);
    $("#sCancelar", d).addEventListener("click", fechar);
    $("#fSenha", d).addEventListener("submit", async (ev) => {
      ev.preventDefault();
      try {
        exigeDono();
        const senha = $("#sNova", d).value;
        if (senha.length < 8) throw new Error("A senha precisa ter pelo menos 8 caracteres.");
        u.sal = novoSal(); u.hash = await hashSenha(senha, u.sal);
        salvar(); fechar(); toast("Senha atualizada.");
      } catch (err) { $("#sErro", d).textContent = err.message; }
    });
  }

  function dialogoConfirmar(titulo, texto, rotulo, aoConfirmar) {
    const d = abrirDialogo(`<h3>${esc(titulo)}</h3><p class="muted" style="margin-top:6px">${esc(texto)}</p>
      <div class="dlg__actions" style="margin-top:20px">
        <button class="btn btn--ghost" type="button" id="cNao">Cancelar</button>
        <button class="btn btn--danger" type="button" id="cSim">${esc(rotulo)}</button></div>`);
    $("#cNao", d).addEventListener("click", fechar);
    $("#cSim", d).addEventListener("click", () => { try { aoConfirmar(); } catch (err) { toast(err.message, true); } fechar(); });
  }

  /* ---------- download de arquivos ---------- */
  function baixar(nome, conteudo, tipo) {
    const url = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
    const a = Object.assign(document.createElement("a"), { href: url, download: nome });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const hoje = () => new Date().toISOString().slice(0, 10);

  function exportarCSV() {
    const dono = ehDono();
    const cab = ["Perfume", "Marca", "Família", "Volume", "Quantidade", "Mínimo", "Situação", "Preço de venda"];
    if (dono) cab.push("Custo");
    const celula = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const linhas = listaFiltrada().map((p) => {
      const e = est(p);
      const l = [p.nome, p.marca, p.familia, p.volume, e.qtd, e.min, ROTULO[situacao(e)], e.preco ?? ""];
      if (dono) l.push(e.custo ?? "");
      return l.map(celula).join(";");
    });
    baixar(`estoque-miraj-${hoje()}.csv`, "\ufeff" + [cab.map(celula).join(";"), ...linhas].join("\r\n"), "text/csv;charset=utf-8");
  }

  function exportarBackup() {
    exigeDono();
    baixar(`backup-estoque-miraj-${hoje()}.json`, JSON.stringify({ tipo: "miraj-estoque", versao: 1, estoque: db.estoque, movs: db.movs }, null, 2), "application/json");
  }

  function exportarProdutosJs() {
    exigeDono();
    const lista = PRODUTOS.map((p) => ({ ...p, preco: est(p).preco ?? null }));
    const cab = "/* MIRAJ PERFUMES — lista de perfumes (gerado pelo painel em " + hoje() + ") */\n";
    baixar("produtos.js", cab + "const PRODUTOS = " + JSON.stringify(lista, null, 2) + ";\n", "text/javascript");
  }

  function importarBackup(arquivo) {
    exigeDono();
    const leitor = new FileReader();
    leitor.onload = () => {
      try {
        const o = JSON.parse(leitor.result);
        if (!o || o.tipo !== "miraj-estoque" || typeof o.estoque !== "object" || !Array.isArray(o.movs)) throw new Error("Arquivo de backup inválido.");
        dialogoConfirmar("Restaurar backup?", "O estoque e o histórico atuais serão substituídos pelos do arquivo. Os usuários não mudam.", "Restaurar", () => {
          exigeDono();
          db.estoque = o.estoque; db.movs = o.movs.slice(0, 500);
          salvar(); renderTudo(); toast("Backup restaurado.");
        });
      } catch (err) { toast(err.message || "Não foi possível ler o arquivo.", true); }
    };
    leitor.readAsText(arquivo);
  }

  /* ---------- eventos ---------- */
  let tentativas = 0;
  let bloqueadoAte = Number(lerLS("miraj-admin-bloqueio") || 0);

  $("#formSetup").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const erro = $("#setupErro"); erro.textContent = "";
    try {
      if (db.usuarios.length) throw new Error("O primeiro acesso já foi feito.");
      const s1 = $("#setupSenha").value;
      if (s1 !== $("#setupSenha2").value) throw new Error("As senhas não conferem.");
      const u = await novoUsuario({ nome: $("#setupNome").value, usuario: $("#setupUsuario").value, senha: s1, papel: "dono" });
      db.usuarios.push(u); salvar();
      iniciarSessao(u); mostrarApp();
    } catch (err) { erro.textContent = err.message; }
  });

  $("#formLogin").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const erro = $("#loginErro"); erro.textContent = "";
    if (Date.now() < bloqueadoAte) { erro.textContent = "Muitas tentativas. Aguarde um minuto e tente de novo."; return; }
    try {
      const nome = $("#loginUsuario").value.trim().toLowerCase();
      const u = db.usuarios.find((x) => x.usuario === nome);
      // calcula o hash mesmo sem usuário, para o tempo de resposta não revelar se ele existe
      const h = await hashSenha($("#loginSenha").value, u ? u.sal : novoSal());
      if (u && h === u.hash) {
        tentativas = 0;
        iniciarSessao(u); mostrarApp();
      } else {
        tentativas++;
        if (tentativas >= 5) { bloqueadoAte = Date.now() + 60000; gravarLS("miraj-admin-bloqueio", String(bloqueadoAte)); tentativas = 0; }
        erro.textContent = "Usuário ou senha incorretos.";
        $("#loginSenha").value = "";
      }
    } catch (err) { erro.textContent = err.message; }
  });

  $("#sair").addEventListener("click", () => encerrarSessao());
  $("#tabs").addEventListener("click", (e) => { const b = e.target.closest("[data-tab]"); if (b) abrirAba(b.dataset.tab); });

  $("#fBusca").addEventListener("input", (e) => { filtro.q = e.target.value; renderTabela(); });
  $("#fFamilia").innerHTML = '<option value="">Todas as famílias</option>' + [...new Set(PRODUTOS.map((p) => p.familia))].sort().map((f) => `<option>${esc(f)}</option>`).join("");
  $("#fFamilia").addEventListener("change", (e) => { filtro.familia = e.target.value; renderTabela(); });
  $("#fStatus").addEventListener("change", (e) => { filtro.status = e.target.value; renderTabela(); });
  $("#fOrdem").addEventListener("change", (e) => { filtro.ordem = e.target.value; renderTabela(); });
  $("#csv").addEventListener("click", exportarCSV);

  $("#tbody").addEventListener("click", (e) => {
    if (!ehDono()) return;
    const inc = e.target.closest("[data-inc]"), dec = e.target.closest("[data-dec]"), aj = e.target.closest("[data-ajustar]");
    if (inc) { const p = produto(inc.dataset.inc); ajusteRapido(p, est(p).qtd + 1, "Ajuste rápido (+1)"); }
    if (dec) { const p = produto(dec.dataset.dec); if (est(p).qtd > 0) ajusteRapido(p, est(p).qtd - 1, "Ajuste rápido (−1)"); }
    if (aj) dialogoAjuste(produto(aj.dataset.ajustar));
  });
  $("#tbody").addEventListener("change", (e) => {
    const campo = e.target.closest("[data-qtd]");
    if (!campo || !ehDono()) return;
    const p = produto(campo.dataset.qtd), v = Number(campo.value);
    if (campo.value === "" || !Number.isInteger(v) || v < 0) { toast("Digite um número inteiro, 0 ou mais.", true); renderTabela(); return; }
    ajusteRapido(p, v, "Ajuste rápido (digitado)");
  });

  $("#usersBody").addEventListener("click", (e) => {
    if (!ehDono()) return;
    const sn = e.target.closest("[data-senha]"), rm = e.target.closest("[data-remover]");
    if (sn) dialogoSenha(db.usuarios.find((u) => u.id === sn.dataset.senha));
    if (rm) {
      const u = db.usuarios.find((x) => x.id === rm.dataset.remover);
      dialogoConfirmar("Remover usuário?", `${u.nome} (${u.usuario}) deixará de ter acesso ao painel.`, "Remover", () => {
        exigeDono();
        if (u.id === sessao.id) throw new Error("Você não pode remover a si mesmo.");
        db.usuarios = db.usuarios.filter((x) => x.id !== u.id);
        salvar(); renderUsuarios(); toast("Usuário removido.");
      });
    }
  });

  $("#formNovoUser").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const erro = $("#nuErro"); erro.textContent = "";
    try {
      exigeDono();
      const u = await novoUsuario({ nome: $("#nuNome").value, usuario: $("#nuUsuario").value, senha: $("#nuSenha").value, papel: $("#nuPapel").value });
      db.usuarios.push(u); salvar();
      ev.target.reset(); renderUsuarios(); toast(`Usuário ${u.usuario} criado.`);
    } catch (err) { erro.textContent = err.message; }
  });

  $("#expJson").addEventListener("click", () => { try { exportarBackup(); } catch (err) { toast(err.message, true); } });
  $("#expProdutos").addEventListener("click", () => { try { exportarProdutosJs(); } catch (err) { toast(err.message, true); } });
  $("#impJson").addEventListener("change", (e) => { const f = e.target.files[0]; e.target.value = ""; if (f) { try { importarBackup(f); } catch (err) { toast(err.message, true); } } });

  /* ---------- início ---------- */
  (function iniciar() {
    // retoma a sessão se a aba continua aberta (e o usuário ainda existe)
    try {
      const s = JSON.parse(lerLS(CHAVE_SESSAO, sessionStorage) || "null");
      const u = s && db.usuarios.find((x) => x.id === s.id);
      if (u && Date.now() - s.t < INATIVIDADE_MS) { iniciarSessao(u); mostrarApp(); return; }
    } catch (e) { /* cai na tela de login */ }
    mostrarTelaLogin();
  })();
})();
