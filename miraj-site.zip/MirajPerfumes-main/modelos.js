/* =========================================================
   MIRAJ PERFUMES — fotos de campanha (modelos)
   - Passam no destaque do início, na ordem abaixo.
   - "slug" liga a foto ao perfume (nome do arquivo em images/, sem .jpg).
     Com slug, ela também vira foto secundária na janela do perfume.
     Sem slug (null), aparece só no início.
   ========================================================= */
const MODELOS = [
  {
    "arquivo": "images/modelos/asad-1.jpg",
    "slug": "asad",
    "alt": "Asad, da Lattafa, nas mãos de um modelo"
  },
  {
    "arquivo": "images/modelos/yara-1.jpg",
    "slug": "yara",
    "alt": "Yara, da Lattafa, em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/asad-bourbon-1.jpg",
    "slug": "asad-bourbon",
    "alt": "Asad Bourbon, da Lattafa, em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/afeef-1.jpg",
    "slug": "afeef",
    "alt": "Afeef, da Lattafa, em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/liquid-brun-1.jpg",
    "slug": "liquid-brun",
    "alt": "French Avenue Liquid Brun em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/yara-elixir-1.jpg",
    "slug": "yara-elixir",
    "alt": "Yara Elixir, da Lattafa, em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/hawas-black-1.jpg",
    "slug": "hawas-black",
    "alt": "Rasasi Hawas Black em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/her-confession-1.jpg",
    "slug": "her-confession",
    "alt": "Her Confession, da Lattafa, em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/9pm-1.jpg",
    "slug": "9pm",
    "alt": "Afnan 9 PM em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/asad-elixir-1.jpg",
    "slug": "asad-elixir",
    "alt": "Asad Elixir, da Lattafa, com perfil olfativo"
  },
  {
    "arquivo": "images/modelos/emeer-1.jpg",
    "slug": "emeer",
    "alt": "Emeer, da Lattafa, em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/asad-bourbon-2.jpg",
    "slug": "asad-bourbon",
    "alt": "Asad Bourbon, da Lattafa, nas mãos de um modelo"
  },
  {
    "arquivo": "images/modelos/atheeri-1.jpg",
    "slug": "atheeri",
    "alt": "Lattafa Atheeri em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/vulcan-feu-1.jpg",
    "slug": "vulcan-feu",
    "alt": "French Avenue Vulcan Feu em cenário tropical"
  },
  {
    "arquivo": "images/modelos/spectre-ghost-1.jpg",
    "slug": "spectre-ghost",
    "alt": "Spectre Ghost em campanha noturna"
  },
  {
    "arquivo": "images/modelos/musamam-1.jpg",
    "slug": "musamam",
    "alt": "Lattafa Musamam em campanha com modelos"
  },
  {
    "arquivo": "images/modelos/pacific-aura-2.jpg",
    "slug": "pacific-aura",
    "alt": "Rayhaan Pacific Aura em campanha com modelo"
  },
  {
    "arquivo": "images/modelos/asad-2.jpg",
    "slug": "asad",
    "alt": "Asad, da Lattafa, nas mãos de uma modelo"
  },
  {
    "arquivo": "images/modelos/asad-bourbon-3.jpg",
    "slug": "asad-bourbon",
    "alt": "Asad Bourbon, da Lattafa, com perfil olfativo"
  },
  {
    "arquivo": "images/modelos/hawas-black-2.jpg",
    "slug": "hawas-black",
    "alt": "Rasasi Hawas Black em campanha masculina"
  },
  {
    "arquivo": "images/modelos/pacific-aura-1.jpg",
    "slug": "pacific-aura",
    "alt": "Rayhaan Pacific Aura com guia de uso"
  },
  {
    "arquivo": "images/modelos/asad-3.jpg",
    "slug": "asad",
    "alt": "Asad, da Lattafa, em campanha masculina"
  },
  {
    "arquivo": "images/modelos/club-de-nuit-imperiale.jpg",
    "slug": null,
    "alt": "Club de Nuit Imperiale, da Armaf"
  },
  {
    "arquivo": "images/modelos/yum-yum-1.jpg",
    "slug": null,
    "alt": "Yum Yum, da Armaf"
  },
  {
    "arquivo": "images/modelos/crimson.jpg",
    "slug": null,
    "alt": "Crimson, da Rayhaan"
  },
  {
    "arquivo": "images/modelos/hawas-ice.jpg",
    "slug": null,
    "alt": "Hawas Ice, da Rasasi"
  },
  {
    "arquivo": "images/modelos/hawas-elixir.jpg",
    "slug": null,
    "alt": "Hawas Elixir, da Rasasi"
  },
  {
    "arquivo": "images/modelos/yum-yum-2.jpg",
    "slug": null,
    "alt": "Yum Yum, da Armaf"
  },
  {
    "arquivo": "images/modelos/his-confession.jpg",
    "slug": null,
    "alt": "His Confession, da Lattafa"
  },
  {
    "arquivo": "images/modelos/pisa.jpg",
    "slug": null,
    "alt": "Pisa, da Lattafa"
  },
  {
    "arquivo": "images/modelos/club-de-nuit-maleka.jpg",
    "slug": null,
    "alt": "Club de Nuit Maleka, da Armaf"
  },
  {
    "arquivo": "images/modelos/amber-oud-gold.jpg",
    "slug": null,
    "alt": "Amber Oud Gold Edition, da Al Haramain"
  },
  {
    "arquivo": "images/modelos/kingdom-women-1.jpg",
    "slug": null,
    "alt": "The Kingdom For Women, da Lattafa"
  },
  {
    "arquivo": "images/modelos/kingdom-women-2.jpg",
    "slug": null,
    "alt": "The Kingdom For Women, da Lattafa"
  },
  {
    "arquivo": "images/modelos/kingdom-women-3.jpg",
    "slug": null,
    "alt": "The Kingdom For Women, da Lattafa"
  },
  {
    "arquivo": "images/modelos/kingdom-women-4.jpg",
    "slug": null,
    "alt": "The Kingdom For Women, da Lattafa"
  },
  {
    "arquivo": "images/modelos/delilah.jpg",
    "slug": null,
    "alt": "Delilah Pour Femme"
  }
];
